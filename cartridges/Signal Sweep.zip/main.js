let tick = 0;
function _update() { tick++; }
function _draw() {
  cls(1);
  const x = 12 + (tick % 232);
  for (let i = 12; i < 245; i += 16) line(i, 32, i, 112, 5);
  line(x, 32, x, 112, 11);
  line(255 - x, 32, 255 - x, 112, 10);
  print("SIGNAL SWEEP", 12, 12, 11);
  print("SOURCE TEST 1.0.1", 12, 125, 7);
}

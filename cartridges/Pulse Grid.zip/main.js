let tick = 0;
function _update() { tick++; }
function _draw() {
  cls(1);
  for (let y = 0; y < 5; y++) {
    for (let x = 0; x < 13; x++) {
      const c = (x + y + Math.floor(tick / 8)) % 5 === 0 ? 9 : 5;
      rectfill(20+x*17, 38+y*15, 29+x*17, 46+y*15, c);
    }
  }
  print("PULSE GRID", 12, 12, 9);
  print("SOURCE TEST 1.0.0", 12, 125, 7);
}
